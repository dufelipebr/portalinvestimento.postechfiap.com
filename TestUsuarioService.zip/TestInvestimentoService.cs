using Bogus;
using Bogus.DataSets;
using Moq;
using System.Collections.Specialized;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.Xml;
using Xunit;
using PortalInvestimento.Domain.Entities;
using PortalInvestimento.Domain.Validation;
using PortalInvestimento.Application.Services;
using PortalInvestimento.Application.Interfaces;



namespace PortalInvestimento.XUnit
{
    /*
     * 
     * AssertionConcern.AssertArgumentNotEmpty(Codigo, "Codigo precisa ser preenchido.");
        AssertionConcern.AssertArgumentLength(Codigo, 50, "Codigo do Investimento precisa ter no maximo 10 caracteres.");
        AssertionConcern.AssertArgumentNotEmpty(Nome, "Nome precisa ser preenchido.");
        AssertionConcern.AssertArgumentLength(Nome, 100, "Nome do Investimento precisa ter no maximo 50 caracteres.");
        AssertionConcern.AssertArgumentNotEquals(TipoInvestimento, 0, "Tipo Investimento precisa ser preenchido");
        AssertionConcern.AssertArgumentRange((double)TaxaADM, 0.1, 10, "Taxa ADM precisa estar entre 0.1 e 10.");
        AssertionConcern.AssertArgumentRange((double)AporteMinimo, 0.1, 1000000, "Aporte Minimo precisa ser maior que 0 e menor que 1.000.00,00");
     * 
     */
    public class TestAtivoService
    {
        private readonly Faker _faker;
        //private readonly portalinvestimento.virtualtilab.com.StringDictionary _sd;

        public TestAtivoService()
        {
            _faker = new Faker();
            //_sd = new portalinvestimento.virtualtilab.com.StringDictionary();
        }

        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Create_ShoulReturnSuccessMessage()
        //{
        //    var mock = new Mock<IAtivoService>();
        //    mock.Setup(service => service.CadastrarAsync(It.IsAny<Ativo>())).Returns("Ok"); // codigo retorno succeso
        //    AtivoService s = new AtivoService();

        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = "";
        //    var taxaADM = 1.0m;

        //    var ativo = new Ativo()
        //    {
        //        Tipo = tipo,
        //        Nome = nome,
        //        Descricao = descricao,
        //        Codigo = codigo,
        //        TaxaADM = taxaADM
        //    });

           
        //    var resultaEsperado = mock.Object.Create(ativo);
        //    string resultado = s.Create(ativo);
                
        //    Assert.Equal(resultaEsperado, resultado);
        //}

        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenCodigo_Empty()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = "";
        //    var taxaADM = 1.0m;



        //    var ativo = new Ativo()
        //    {
        //        Tipo = tipo,
        //        Nome = nome,
        //        Descricao = descricao,
        //        Codigo = codigo,
        //        TaxaADM = taxaADM
        //    });

        //    //act
        //    var result = Assert.Throws<DomainException>(() => ativo);


        //    Assert.Equal("Codigo precisa ser preenchido.", result.Message);

        //}


        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenCodigo_Higher()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(51); ;
        //    var taxaADM = 1.0m;

        //    var result = Assert.Throws<DomainException>(() => new Ativo()
        //    {
        //        Tipo = tipo,
        //        Nome = nome,
        //        Descricao = descricao,
        //        Codigo = codigo,
        //        TaxaADM = taxaADM
        //    });


        //    Assert.Equal("Codigo do Investimento precisa ter no maximo 50 caracteres.", result.Message);
        //}


        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenNome_Empty()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = string.Empty;
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = 1.0m;
        //    var aporteMinimo = 10m;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;


        //    var result = Assert.Throws<DomainException>(() => new Ativo()
        //    {
        //        Tipo = tipo,
        //        Nome = nome,
        //        Descricao = descricao,
        //        Codigo = codigo,
        //        TaxaADM = taxaADM
        //    });

        //    Assert.Equal("Nome precisa ser preenchido.", result.Message);

        //}


        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenNome_Higher()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(101);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = 1.0m;
        //    var aporteMinimo = 10m;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;

            
        //    var result = Assert.Throws<DomainException>(() => new Ativo()
        //    {
        //        Tipo = tipo,
        //        Nome = nome,
        //        Descricao = descricao,
        //        Codigo = codigo,
        //        TaxaADM = taxaADM
        //    });
            
        //    Assert.Equal("Nome do Investimento precisa ter no maximo 100 caracteres.", result.Message);

        //}


        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenTaxaAdm_Lower()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = -0.1m;
        //    var aporteMinimo = 10m;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;

        //    //act
        //    var result = Assert.Throws<DomainException>(() => new Ativo(tipo, nome, descricao, codigo, taxaADM, aporteMinimo, rent_3, rent_12, rent_24));
        //    //Assert.Throws<DomainException>()

        //    //Assert
        //    Assert.Equal("Taxa ADM precisa estar entre 0.1 e 10.", result.Message);

        //}

        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenTaxaAdm_Higher()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = 10.5m;
        //    var aporteMinimo = 10m;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;

        //    //act
        //    var result = Assert.Throws<DomainException>(() => new Ativo(tipo, nome, descricao, codigo, taxaADM, aporteMinimo, rent_3, rent_12, rent_24));
        //    //Assert.Throws<DomainException>()

        //    //Assert
        //    Assert.Equal("Taxa ADM precisa estar entre 0.1 e 10.", result.Message);

        //}

        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenAporteMinimo_Lower()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = 10m;
        //    var aporteMinimo = 0;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;

        //    //act
        //    var result = Assert.Throws<DomainException>(() => 
        //    new Ativo(
        //        tipo, nome, descricao, codigo, taxaADM, aporteMinimo, rent_3, rent_12, rent_24));
        //    //Assert.Throws<DomainException>()

        //    //Assert
        //    Assert.Equal("Aporte Minimo precisa ser maior que 0 e menor que 1.000.00,00", result.Message);

        //}


        //[Fact]
        //[Trait("Categoria", "Validando Investimento")]
        //public void Investimento_ShouldThrowException_WhenAporteMinimo_Higher()
        //{
        //    // Arrange
        //    var tipo = Ativo.enTipoInvestimento.CDI;
        //    var nome = _faker.Random.String2(100);
        //    var descricao = _faker.Random.String2(500);
        //    var codigo = _faker.Random.String2(10);
        //    var taxaADM = 10m;
        //    var aporteMinimo = 20000000000;
        //    var rent_3 = 7.1m;
        //    var rent_12 = 20.3m;
        //    var rent_24 = 40.0m;

        //    //act
        //    var result = Assert.Throws<DomainException>(() =>
        //    new Ativo(
        //        tipo, nome, descricao, codigo, taxaADM, aporteMinimo, rent_3, rent_12, rent_24));
        //    //Assert.Throws<DomainException>()

        //    //Assert
        //    Assert.Equal("Aporte Minimo precisa ser maior que 0 e menor que 1.000.00,00", result.Message);

        //}











    }
}